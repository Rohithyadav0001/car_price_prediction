fastapi
uvicorn[standard]
scikit-learn
pandas
numpy
python-multipart
pydantic